import pytesseract,sys
import cv2
from tkinter import *
from tkinter.filedialog import askopenfilename 

def ocr_core(img):
    text = pytesseract.image_to_string(img)
    return text
filename = "WhatsApp_Image_2020-10-11_at_18.16.48.jpeg"
def openfile(img):
    #filename = askopenfilename(initialdir="/Pictures", filetypes =[('jpeg files', '*.jpg'),("png files","*.png"),("all files","*.*")]) 	
    img = cv2.imread(img)
    def grayscale(img):
        return cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    def antiblur(img):
        return cv2.medianBlur(img,5)
    def threshold(img):
        return  cv2.threshold(img,0,255,cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1] 
    img = grayscale(img)
    img = antiblur(img)
    img = threshold(img)
    print(ocr_core(img))
openfile(filename)

